# react-simple-o2o-demo

订单评价，文档参见[这里](./docs/README.md)